import React, { useState, useEffect, useCallback } from 'react';
import { apiRequest } from '../utils/apiCaller';



const emptyForm = {
    slno: '',
    departmentname: '',
    acronym: '',
    isTrain: false,
    strengthRequired: '',
    categoryId: '',
};

const DepartmentManagement = () => {
    const [companies, setCompanies] = useState([]);
    const [categories, setCategories] = useState([]);
    const [selectedCompanyId, setSelectedCompanyId] = useState('');
    const [departments, setDepartments] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingDepartment, setEditingDepartment] = useState(null);
    const [formData, setFormData] = useState(emptyForm);
    const [debouncedSearch, setDebouncedSearch] = useState(searchTerm);

    useEffect(() => {
      const timer = setTimeout(() => {
        setDebouncedSearch(searchTerm);
        setPage(1); // reset page on search
      }, 500);

      return () => clearTimeout(timer);
    }, [searchTerm]);

    // Step 1: Fetch companies on mount only
    useEffect(() => {
        const fetchCompanies = async () => {
            try {
                const companiesData = await apiRequest('/companies');
                setCompanies(companiesData);
                if (companiesData.length > 0) {
                    setSelectedCompanyId(companiesData[0].id);
                }
            } catch (err) {
                setError('Failed to fetch companies.');
                console.error(err);
            } finally {
                setLoading(false);
            }
        };
        fetchCompanies();
    }, []);

    const fetchDepartmentList = useCallback(async () => {
      if (!selectedCompanyId) return;
      setLoading(true);
      try {
        const [deptRes, catData] = await Promise.all([
          apiRequest(
            `/departments?companyId=${selectedCompanyId}&page=${page}&limit=10&search=${debouncedSearch}`,
          ),
          apiRequest(`/categories?companyId=${selectedCompanyId}`),
        ]);

        const rows = deptRes.data || (Array.isArray(deptRes) ? deptRes : []);
        setDepartments(rows);
        setTotalPages(deptRes.totalPages || 1);
        setCategories(Array.isArray(catData) ? catData : catData.data || []);
        setError(null);
      } catch (err) {
        setError(err.message || "Failed to fetch data.");
      } finally {
        setLoading(false);
      }
    }, [selectedCompanyId, page, debouncedSearch]);

    // Step 2: Fetch departments + categories together when company, page or search changes
    useEffect(() => {
      fetchDepartmentList();
    }, [fetchDepartmentList]);

    const handleCompanyChange = (e) => setSelectedCompanyId(e.target.value);
    const handleSearchChange = (e) => setSearchTerm(e.target.value);

    const openAddModal = () => {
        setEditingDepartment(null);
        setFormData(emptyForm);
        setIsModalOpen(true);
    };

    const openEditModal = (department) => {
        setEditingDepartment(department);
        setFormData({
            slno: department.slno,
            departmentname: department.departmentname,
            acronym: department.acronym,
            isTrain: department.isTrain,
            strengthRequired: department.strengthRequired,
            categoryId: department.categoryId,
        });
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setEditingDepartment(null);
    };

    const handleFormSubmit = async (e) => {
        e.preventDefault();
        const payload = {
            ...formData,
            slno: parseInt(formData.slno, 10),
            strengthRequired: parseFloat(formData.strengthRequired) || 0,
            categoryId: parseInt(formData.categoryId, 10),
            companyId: parseInt(selectedCompanyId, 10),
        };

        try {
            if (editingDepartment) {
                await apiRequest(`/departments/${editingDepartment.id}`, {
                    method: 'PUT',
                    body: JSON.stringify(payload),
                });
            } else {
                await apiRequest('/departments', {
                    method: 'POST',
                    body: JSON.stringify(payload),
                });
            }
            await fetchDepartmentList();
            closeModal();
        } catch (err) {
            setError(err.message || (editingDepartment ? 'Failed to update department.' : 'Failed to create department.'));
            console.error(err);
        }
    };

    const handleDelete = async (id) => {
        if (!window.confirm('Are you sure you want to delete this department?')) return;
        try {
            await apiRequest(`/departments/${id}`, { method: 'DELETE' });
            await fetchDepartmentList();
        } catch (err) {
            setError(err.message || 'Failed to delete department.');
            console.error(err);
        }
    };

    const selectedCompany = companies.find(c => c.id === Number(selectedCompanyId));
  

    if (loading && companies.length === 0) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
                <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
            </div>
        );
    }

    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-800 flex items-center gap-3 mb-2">
            <span className="text-3xl">🏢</span> Department Management
          </h1>
          <p className="text-slate-600">
            Manage departments across your organization
          </p>
        </div>

        {/* Company Selector */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex flex-col md:flex-row items-end gap-4">
            <div className="flex-1">
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Select Company
              </label>
              <select
                value={selectedCompanyId}
                onChange={handleCompanyChange}
                className="w-full px-4 py-2.5 border border-slate-300 rounded-lg bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {companies.map((company) => (
                  <option key={company.id} value={company.id}>
                    {company.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 text-red-800 flex items-start gap-3">
            <svg
              className="w-5 h-5 mt-0.5 flex-shrink-0"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path
                fillRule="evenodd"
                d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                clipRule="evenodd"
              />
            </svg>
            <span>{error}</span>
          </div>
        )}

        {/* Search and Add Bar */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <svg
                  className="absolute left-3 top-3 w-5 h-5 text-slate-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
                <input
                  type="text"
                  placeholder="Search by name or acronym..."
                  value={searchTerm}
                  onChange={handleSearchChange}
                  className="w-full pl-10 pr-4 py-2.5 border border-slate-300 rounded-lg bg-slate-50 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            <button
              onClick={openAddModal}
              className="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all shadow-md hover:shadow-lg active:scale-95 flex items-center justify-center gap-2"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path
                  fillRule="evenodd"
                  d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z"
                  clipRule="evenodd"
                />
              </svg>
              Add Department
            </button>
          </div>
        </div>

        {/* Departments Table */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {loading ? (
            <div className="flex justify-center items-center p-12">
              <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gradient-to-r from-slate-700 to-slate-800 text-white">
                    <th className="px-4 py-4 text-left text-sm font-semibold">
                      Sl.No
                    </th>
                    <th className="px-4 py-4 text-left text-sm font-semibold">
                      Department Name
                    </th>
                    <th className="px-4 py-4 text-left text-sm font-semibold">
                      Acronym
                    </th>
                    <th className="px-4 py-4 text-left text-sm font-semibold">
                      Category
                    </th>
                    <th className="px-4 py-4 text-center text-sm font-semibold">
                      Training
                    </th>
                    <th className="px-4 py-4 text-center text-sm font-semibold">
                      Strength Req.
                    </th>
                    <th className="px-4 py-4 text-center text-sm font-semibold">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {departments.length > 0 ? (
                    departments.map((dept, index) => (
                      <tr
                        key={dept.id}
                        className={`border-b border-slate-200 hover:bg-slate-50 transition-colors ${index % 2 === 0 ? "bg-white" : "bg-slate-50"}`}
                      >
                        <td className="px-4 py-4 text-sm text-slate-600">
                          {index + 1 + (page - 1) * 10}
                        </td>
                        <td className="px-4 py-4 text-sm text-slate-900 font-medium">
                          {dept.departmentname}
                        </td>
                        <td className="px-4 py-4 text-sm">
                          <span className="px-2 py-1 bg-slate-100 text-slate-700 rounded font-mono text-xs">
                            {dept.acronym}
                          </span>
                        </td>
                        <td className="px-4 py-4 text-sm text-slate-600">
                          {dept.category?.categoryName || "—"}
                        </td>
                        <td className="px-4 py-4 text-sm text-center">
                          <span
                            className={`px-3 py-1 rounded-full text-xs font-semibold ${dept.isTrain ? "bg-blue-100 text-blue-800" : "bg-slate-100 text-slate-600"}`}
                          >
                            {dept.isTrain ? "Yes" : "No"}
                          </span>
                        </td>
                        <td className="px-4 py-4 text-sm text-center font-semibold text-slate-700">
                          {dept.strengthRequired}
                        </td>
                        <td className="px-4 py-4 text-sm text-center">
                          <div className="flex items-center justify-center gap-2">
                            <button
                              onClick={() => openEditModal(dept)}
                              className="p-2 rounded-lg bg-blue-100 text-blue-600 hover:bg-blue-200 transition-colors"
                              title="Edit"
                            >
                              <svg
                                className="w-4 h-4"
                                fill="currentColor"
                                viewBox="0 0 20 20"
                              >
                                <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                              </svg>
                            </button>
                            <button
                              onClick={() => handleDelete(dept.id)}
                              className="p-2 rounded-lg bg-red-100 text-red-600 hover:bg-red-200 transition-colors"
                              title="Delete"
                            >
                              <svg
                                className="w-4 h-4"
                                fill="currentColor"
                                viewBox="0 0 20 20"
                              >
                                <path
                                  fillRule="evenodd"
                                  d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z"
                                  clipRule="evenodd"
                                />
                              </svg>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="7" className="px-6 py-12 text-center">
                        <div className="text-slate-500">
                          <svg
                            className="w-12 h-12 mx-auto mb-3 text-slate-400"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"
                            />
                          </svg>
                          <p className="text-lg font-medium">
                            No departments found
                          </p>
                          <p className="text-sm mt-1">
                            Add a new department to get started
                          </p>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
        <div className="flex justify-center items-center gap-3 p-4">
          <button
            disabled={page === 1}
            onClick={() => setPage((prev) => prev - 1)}
            className="px-4 py-2 bg-slate-200 rounded disabled:opacity-50"
          >
            Prev
          </button>

          <span className="text-sm font-semibold">
            Page {page} of {totalPages}
          </span>

          <button
            disabled={page === totalPages}
            onClick={() => setPage((prev) => prev + 1)}
            className="px-4 py-2 bg-slate-200 rounded disabled:opacity-50"
          >
            Next
          </button>
        </div>

        {/* Modal */}
        {isModalOpen && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="relative bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-screen overflow-y-auto">
              {/* Close button */}
              <button
                onClick={closeModal}
                aria-label="Close"
                className="absolute top-4 right-4 w-10 h-10 flex items-center justify-center rounded-full text-red-500 hover:text-red-700 text-2xl font-bold transition-all z-10"
              >
                ×
              </button>

              {/* Modal Header */}
              <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-5 rounded-t-xl">
                <h2 className="text-xl font-bold">
                  {editingDepartment
                    ? "✏️ Edit Department"
                    : "➕ Add New Department"}
                </h2>
              </div>

              {/* Modal Body */}
              <form onSubmit={handleFormSubmit} className="p-6">
                <div className="space-y-5">
                  {/* Company (read-only) */}
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">
                      Company
                    </label>
                    <input
                      type="text"
                      value={selectedCompany?.name || ""}
                      disabled
                      className="w-full px-4 py-2.5 bg-slate-100 border border-slate-300 rounded-lg text-slate-600 cursor-not-allowed"
                    />
                  </div>

                  {/* Sl.No */}
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">
                      Sl.No <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      value={formData.slno}
                      onChange={(e) =>
                        setFormData({ ...formData, slno: e.target.value })
                      }
                      placeholder="e.g., 1"
                      required
                      min="1"
                      className="w-full px-4 py-2.5 border border-slate-300 rounded-lg text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>

                  {/* Department Name */}
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">
                      Department Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.departmentname}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          departmentname: e.target.value,
                        })
                      }
                      placeholder="e.g., Human Resources"
                      required
                      className="w-full px-4 py-2.5 border border-slate-300 rounded-lg text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>

                  {/* Acronym and Strength Required - side by side */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        Acronym <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={formData.acronym}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            acronym: e.target.value.toUpperCase(),
                          })
                        }
                        maxLength="10"
                        placeholder="e.g., HR"
                        required
                        className="w-full px-4 py-2.5 border border-slate-300 rounded-lg text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono uppercase"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        Strength Required{" "}
                        <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="number"
                        value={formData.strengthRequired}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            strengthRequired: e.target.value,
                          })
                        }
                        placeholder="e.g., 50"
                        required
                        min="0"
                        className="w-full px-4 py-2.5 border border-slate-300 rounded-lg text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                  </div>

                  {/* Category */}
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">
                      Category <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={formData.categoryId}
                      onChange={(e) =>
                        setFormData({ ...formData, categoryId: e.target.value })
                      }
                      required
                      className="w-full px-4 py-2.5 border border-slate-300 rounded-lg bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="">-- Select Category --</option>
                      {categories.map((cat) => (
                        <option key={cat.id} value={cat.id}>
                          {cat.categoryName}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Is Training */}
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-3">
                      Is Training Department?
                    </label>
                    <div className="flex gap-6">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="isTrain"
                          value="true"
                          checked={
                            formData.isTrain === true ||
                            formData.isTrain === "true"
                          }
                          onChange={() =>
                            setFormData({ ...formData, isTrain: true })
                          }
                          className="w-4 h-4 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="text-sm text-slate-700 font-medium">
                          Yes
                        </span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="isTrain"
                          value="false"
                          checked={
                            formData.isTrain === false ||
                            formData.isTrain === "false"
                          }
                          onChange={() =>
                            setFormData({ ...formData, isTrain: false })
                          }
                          className="w-4 h-4 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="text-sm text-slate-700 font-medium">
                          No
                        </span>
                      </label>
                    </div>
                  </div>
                </div>

                {/* Modal Actions */}
                <div className="flex gap-3 mt-8">
                  <button
                    type="button"
                    onClick={closeModal}
                    className="flex-1 px-4 py-2.5 border border-slate-300 text-slate-700 font-semibold rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 px-4 py-2.5 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all active:scale-95"
                  >
                    {editingDepartment
                      ? "Update Department"
                      : "Save Department"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    );
};

export default DepartmentManagement;
